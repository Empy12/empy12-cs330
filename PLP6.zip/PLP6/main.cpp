#include <iostream>
using namespace std;

int theVar(int w){
int x = w;
return x;

}

void testRef(int &ref){
    ref = ref * 2;

}


int main() {
    int x = 0;
    cout << x;
    cout << "\n";
    while (x < 5){
        x += 1;
    }
    cout << x;
    cout << "\n";
    int y = theVar(x);
    cout << y;
    cout << "\n";
    testRef(y);


    char a [] = {'c','a','t'};
    char b [] = {'d','o','g'};
   //a = b; this line gives an error
    b[1] = 'u';
    cout << a;
    cout << "\n";
    cout << b;
    cout << "\n";
    return 0;

}
