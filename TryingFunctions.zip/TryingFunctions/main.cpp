#include <iostream>
using namespace std;


//this is both the multiplier, and the pass by value function
int mult(int a, int b){
    int c;
    c = a * b;
    return c;

}

//i think i did recursion right...maybe not though
int recurs(int a){
    a += 1;
    if (a < 10){
        recurs(a);
    }
    else{
        return a;
    }
}

//not possible to return multiple things
string strfunction(string a){
return a;

}

//C++ does both pass by reference and pass by value
// i am attempting pass by reference here
void switchnums(int &a, int &b) {
int z = a;
a = b;
b = z;
}



int main() {
    std::cout << "Hello, World!" << std::endl;
    int multiplied;
    multiplied = mult (6,8);
    std::cout << multiplied << std::endl;
    int rcrsd = recurs(2);
    cout << rcrsd;
    string strrr = strfunction("testing");
    cout << strrr;
    int addnum1 = 4;
    int addnum2 = 7;
    switchnums(addnum1, addnum2);
    cout << addnum1; //should be 7
    cout<< addnum2; //should be 4



    return 0;
}

