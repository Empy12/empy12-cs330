#include <iostream>
using namespace std;

int main() {
    std::cout << "Hello, World!" << std::endl;
//IF + ELSE + ELSE IF STATEMENTS

    int a = 2;

    if ( a == 2 ) {
        cout << "The integer is 2 \n";
    } else {
        cout << "The integer is not 2 \n";
    }

    if ( a == 5 ) {
        cout << "The integer is 5 \n";
    } else {
        cout << "The integer is not 5 \n";
    }

    if ( a != 2 ) {
        cout << "This is not two \n";
    } else if ( a == 2 ) {
        cout << "But it is two \n";
    } else {
        cout << "Surprise it's something else \n";
    }


//IF ELSE but with MULTIPLE CONDITIONS
int b = 7;
if (b > 4 && b < 10){
    cout << "It is greater than for and less than ten! \n";
} else{
    cout << "It's either less than four or greater than ten \n";
}

if (b > 10 || b < 2){
    cout << "Well this number is too big or too little \n";

} else {
    cout << "This number is Just right! \n";
}


if (b > 4 && b < 10) {
        cout << "This is a nice number \n";
} else if ( b > 6 && b < 8) {
        cout << "The number is actually seven \n";
} else {
        cout << "Surprise it's something else \n";
}


//LOOPS


//FOR LOOP

    for(int tst = 0 ; tst <= 12 ; tst+=2 ){
    cout << tst << "\n";
}


//WHILE LOOP

while (b < 14) {
    cout << b << "\n";
    b++;
}


//DO WHILE LOOP (condition checked at end, this is so neat!!)//
do {
    cout << a << "\n";
    a++;
} while ( a < 10 );

//TESTING BREAK!//


for (int i = 0; i < 10; i++){
    if (i == 6){
        break;
    }

    cout << i;

}
cout << "\n";

//TESTING CONTINUE//

for (int i = 0; i < 10; i++){
    if (i == 6){
        continue;
    }

    cout << i;

}
cout << "\n";

//SWITCH STATEMENT//
int rate = 6;

switch(rate) {
    case 2:
        cout << "eh";
        break;
    case 4:
        cout << "could do better";
        break;
    case 6:
        cout << "above average!!";
        break;
    case 8:
        cout << "a fantastic job done!";
        break;
    case 10:
        cout << "perfect rating";
        break;
    default:
        cout <<"Not a valid rating";
}
cout << "\n";



return 0;
}
